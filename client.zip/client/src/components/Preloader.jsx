import React from 'react'

function Preloader(value) {

    return(
        <div id="preloder">
		<div class="loader"></div>
	    </div>
    )
    
} 

export default Preloader